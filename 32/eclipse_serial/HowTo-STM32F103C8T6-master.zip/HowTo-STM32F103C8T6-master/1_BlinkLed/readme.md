This is an very basic example for this uC, that bliks led on integrated led on pin PC13.
