# HowTo-STM32F103C8T6
The very first steps to generic STM32F103C8T6 uC from east.

In this site i will explain, how to deal with this cheap but powerful microController. There is a lot of other developement boards, some of them came from big brands, but this is really small and cheap, so it is suitable for beginners.

This are just a few words about it, more detailes i will publish in wiki.

The projects published here will be created with eclipse CDT luna + GNU ARM Eclipse Plug-ins + GNU Tools for ARM Embedded Processors

1_BlikLed (Blinking Led on build-in pin PC13)
